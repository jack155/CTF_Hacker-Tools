<html>
<head>
<title>
Forgot Password
</title>
</head>
<body bgcolor="#000000">
<div align="right">
<a style="font-size:.8em;color:#FFFF00" href='index.php'><img src="../images/Home.png" height='45'; width='45'></br>HOME</a>
</div>
<div style=" margin-top:200px;color:#FFF; font-size:24px; text-align:center">
<center>
<img src="../images/pass-forgot.jpg">
</center>
</div>
</body>
</html>
