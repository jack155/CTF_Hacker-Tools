<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1324136400104" ID="ID_1494913344" MODIFIED="1367248865653" TEXT="SQL Injections-Page-2">
<node CREATED="1324136425237" HGAP="-20" ID="ID_903641389" MODIFIED="1352118718739" POSITION="right" TEXT="Less-22" VSHIFT="25">
<icon BUILTIN="pencil"/>
<node CREATED="1324136506469" ID="ID_456038241" MODIFIED="1367248146489" TEXT="Cookie Injection - base64 encoded - double quotes" VSHIFT="12">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324136501788" HGAP="-1" ID="ID_1198941000" MODIFIED="1352118867823" POSITION="right" TEXT="Less - 24" VSHIFT="7">
<icon BUILTIN="pencil"/>
<node CREATED="1324136690771" HGAP="15" ID="ID_85068748" MODIFIED="1352119934128" TEXT="POST- Second Oder Injections *Real treat* - Stored Injections" VSHIFT="14">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324136429162" HGAP="-14" ID="ID_194436165" MODIFIED="1352118895613" POSITION="left" TEXT="Less-21" VSHIFT="420">
<icon BUILTIN="pencil"/>
<node CREATED="1324137533985" ID="ID_1551007752" MODIFIED="1352119267149" TEXT="Cookie injection- base64 encoded-single quotes and parenthesis" VSHIFT="14">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324136441860" HGAP="-1" ID="ID_351889515" MODIFIED="1352118743249" POSITION="left" STYLE="fork" TEXT="Less - 23" VSHIFT="5">
<icon BUILTIN="pencil"/>
<node CREATED="1324137615576" HGAP="17" ID="ID_201265776" MODIFIED="1352119761351" TEXT="GET - Error based - strip comments" VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137319383" HGAP="11" ID="ID_853573586" MODIFIED="1352118867003" POSITION="right" TEXT="Less - 25a" VSHIFT="-3">
<icon BUILTIN="pencil"/>
<node CREATED="1324137333904" HGAP="17" ID="ID_429405468" MODIFIED="1354444177636" TEXT="GET - Blind Based - All your OR &amp; AND belong to us- Intiger based" VSHIFT="14">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137466548" HGAP="3" ID="ID_117543297" MODIFIED="1352118869722" POSITION="left" TEXT="Less - 25" VSHIFT="4">
<icon BUILTIN="pencil"/>
<node CREATED="1324137630177" ID="ID_831348399" MODIFIED="1352121365866" TEXT="GET - Error based - All your OR &amp; AND belong to us -string single quote" VSHIFT="16">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137707627" HGAP="15" ID="ID_1410936587" MODIFIED="1352118833323" POSITION="right" TEXT="Less - 26a" VSHIFT="-1">
<icon BUILTIN="pencil"/>
<node CREATED="1324137874201" HGAP="21" ID="ID_1403477223" MODIFIED="1367248118812" TEXT="GET - Blind Based - All your SPACES and COMMENTS belong to us -String-single quotes-Parenthesis" VSHIFT="18">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137711332" HGAP="12" ID="ID_824569291" MODIFIED="1352118829707" POSITION="left" TEXT="Less - 26" VSHIFT="-3">
<icon BUILTIN="pencil"/>
<node CREATED="1324137896185" HGAP="16" ID="ID_1830668257" MODIFIED="1352120084296" TEXT="GET - Error based - All your SPACES and COMMENTS belong to us" VSHIFT="17">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137714364" HGAP="16" ID="ID_188847598" MODIFIED="1352118864836" POSITION="right" TEXT="Less - 27a" VSHIFT="4">
<icon BUILTIN="pencil"/>
<node CREATED="1324137878394" HGAP="18" ID="ID_1523865604" MODIFIED="1354444360799" TEXT="GET - Blind Based- All your UNION &amp; SELECT Belong to us - Double Quotes" VSHIFT="17">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137717348" HGAP="14" ID="ID_1523381996" MODIFIED="1352118871586" POSITION="left" TEXT="Less - 27" VSHIFT="-13">
<icon BUILTIN="pencil"/>
<node CREATED="1324137890129" HGAP="16" ID="ID_1287016606" MODIFIED="1352123147198" TEXT="GET - Error Based- All your UNION &amp; SELECT Belong to us - String - Single quote" VSHIFT="17">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259455429" HGAP="14" ID="ID_466917223" MODIFIED="1352118865949" POSITION="right" TEXT="Less - 28a" VSHIFT="8">
<icon BUILTIN="pencil"/>
<node CREATED="1337259473888" ID="ID_962658043" MODIFIED="1354444425788" TEXT="GET - Blind Based- All your UNION &amp; SELECT Belong to us -single quote-parenthesis" VSHIFT="21">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259571346" HGAP="13" ID="ID_808975697" MODIFIED="1352118853255" POSITION="left" TEXT="Less - 28" VSHIFT="-9">
<icon BUILTIN="pencil"/>
<node CREATED="1337259649440" HGAP="19" ID="ID_190240143" MODIFIED="1352123161809" TEXT="GET - Error Based- All your UNION &amp; SELECT Belong to us - String -Single quote with parenthesis" VSHIFT="13">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259743007" HGAP="25" ID="ID_889999997" MODIFIED="1354483118095" POSITION="right" TEXT="Less - 30" VSHIFT="2">
<icon BUILTIN="pencil"/>
<node CREATED="1337260036723" HGAP="23" ID="ID_470682976" MODIFIED="1354484645340" TEXT="GET - BLIND - IMPIDENCE MISMATCH- Having a WAF in front of web application." VSHIFT="21">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259745713" HGAP="10" ID="ID_1208232472" MODIFIED="1354447785882" POSITION="left" TEXT="Less - 29" VSHIFT="1">
<icon BUILTIN="pencil"/>
<node CREATED="1337260017152" HGAP="22" ID="ID_778159028" MODIFIED="1354484720984" TEXT="GET -Error based- IMPIDENCE MISMATCH- Having a WAF in front of web application. " VSHIFT="13">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259760351" HGAP="18" ID="ID_1236630160" MODIFIED="1354483238450" POSITION="right" TEXT="Less - 32" VSHIFT="4">
<icon BUILTIN="pencil"/>
<node CREATED="1337260042429" ID="ID_1831469301" MODIFIED="1367247180406" TEXT="GET - Bypass custom filter adding slashes to dangerous chars." VSHIFT="16">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259762765" HGAP="3" ID="ID_1521023455" MODIFIED="1354483122526" POSITION="left" TEXT="Less - 31" VSHIFT="-14">
<icon BUILTIN="pencil"/>
<node CREATED="1337260056500" HGAP="18" ID="ID_1620579356" MODIFIED="1354484858206" TEXT="GET - BLIND - IMPIDENCE MISMATCH- Having a WAF in front of web application." VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259768974" HGAP="13" ID="ID_1264770325" MODIFIED="1354483249462" POSITION="right" TEXT="Less - 34" VSHIFT="-1">
<icon BUILTIN="pencil"/>
<node CREATED="1337260049111" HGAP="22" ID="ID_1399680041" MODIFIED="1367247215971" TEXT="POST - Bypass AddSlashes()" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259771723" HGAP="-3" ID="ID_371433913" MODIFIED="1354483152433" POSITION="left" TEXT="Less - 33" VSHIFT="-19">
<icon BUILTIN="pencil"/>
<node CREATED="1337260061967" HGAP="23" ID="ID_1507876679" MODIFIED="1367247198135" TEXT="GET - Bypass AddSlashes()" VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286635272" HGAP="8" ID="ID_1025670211" MODIFIED="1354483293657" POSITION="right" TEXT="Less-36" VSHIFT="5">
<icon BUILTIN="pencil"/>
<node CREATED="1337286752435" ID="ID_586679887" MODIFIED="1367616839750" TEXT="GET - Bypass MySQL_real_escape_string " VSHIFT="20">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286664875" HGAP="-16" ID="ID_622646021" MODIFIED="1354483261494" POSITION="left" TEXT="Less-35" VSHIFT="-1">
<icon BUILTIN="pencil"/>
<node CREATED="1337286733038" HGAP="19" ID="ID_1658696559" MODIFIED="1367406281017" TEXT="GET - Bypass Add Slashes (we dont need them) Integer based" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286811307" HGAP="-13" ID="ID_675480068" MODIFIED="1354483306552" POSITION="right" TEXT="Less-38" VSHIFT="-184">
<icon BUILTIN="pencil"/>
<node CREATED="1337287084942" HGAP="21" ID="ID_471107631" MODIFIED="1337342719626" TEXT="Future Editions" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286920172" HGAP="-35" ID="ID_38136745" MODIFIED="1354483299766" POSITION="left" TEXT="Less-37" VSHIFT="-500">
<icon BUILTIN="pencil"/>
<node CREATED="1337287063065" HGAP="16" ID="ID_58695417" MODIFIED="1367616874200" TEXT="POST- Bypass MySQL_real_escape_string" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
</node>
</map>
