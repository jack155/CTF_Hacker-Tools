* # hackbar2.1.3
* firefox hackbar收费前的残留版本</br>
使用方法</br>
打开firefox的插件目录</br>
![Image text](./img/1.png)

* 然后点这里</br>
![Image text](./img/2.png)</br>
* ### 加载{4c98c9c7-fc13-4622-b08a-a18923469c1c}.xpi  即可

* ### 一定记住要关闭插件的自动更新！！！，否则浏览器会自动更新插件到收费版本！！!  
* 设置方法如下图所示:</br>
![unable updae](./img/3.png)

* PS: 插件来源于:  
这里: https://github.com/HCTYMFF/hackbar2.1.3  
想单独下载插件的可以使用 `GitZip for github` 这个chrome插件来下载，详情使用下载相关插件的方法可以参考我另一个 `repo` 里面的介绍下面的 `Tips`: [https://github.com/Mr-xn/BurpSuite-collections](https://github.com/Mr-xn/BurpSuite-collections)

- update:artificial_satellite: 添加适用于chrome浏览器的 [HackBar-v2.2.6.zip](./HackBar-v2.2.6.zip) 解压后使用开发者模式导入使用。