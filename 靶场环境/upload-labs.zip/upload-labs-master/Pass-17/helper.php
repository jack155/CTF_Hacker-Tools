<?php
if($_GET['action'] == 'get_prompt'){
    echo '本pass重新渲染了图片！';
}
?>