</div>
		<div id="footer">
			<center>Copyright&nbsp;@&nbsp;<span id="copyright_time"></span>&nbsp;by&nbsp;<a href="http://gv7.me" target="_bank">c0ny1</a></center>
		</div>
		<div class="mask"></div>
		<div class="dialog">
		    <div class="dialog-title">提&nbsp;示<a href="javascript:void(0)" class="close" title="关闭">关闭</a></div>
		    <div class="dialog-content"></div>
		</div>		
</body>
<script type="text/javascript" src="<?php echo APP_URL_ROOT;?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo APP_URL_ROOT;?>/js/prism.js"></script>
<script type="text/javascript" src="<?php echo APP_URL_ROOT;?>/js/prism-line-numbers.min.js"></script>
<script type="text/javascript" src="<?php echo APP_URL_ROOT;?>/js/prism-php.min.js"></script>
<script type="text/javascript" src="<?php echo APP_URL_ROOT;?>/js/index.js"></script>
</html>
