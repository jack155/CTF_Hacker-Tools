<?php
if($_GET['action'] == 'get_prompt'){
    echo '本pass检查图标内容开头2个字节！';
}
?>